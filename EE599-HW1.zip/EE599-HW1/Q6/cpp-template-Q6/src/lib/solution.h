#ifndef TEMPLATE_SOLUTION_H
#define TEMPLATE_SOLUTION_H

#include <string>
#include <vector>

class Solution {
public:
  std::string PrintHelloWorld();

  int FactorialRecursive(int n);
  int FactorialIterative(int n);
};

#endif