#include "solution.h"

std::string Solution::PrintHelloWorld() { 

  std::string name = "Krishna Sai Tarun pasupuleti!";
  std::string info = "\nThis is for the course EE599- Assignment 1- Q4!";
  return "My name is " + name + info;
}

